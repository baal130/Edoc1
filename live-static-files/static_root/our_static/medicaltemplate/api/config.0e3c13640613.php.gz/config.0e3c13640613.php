<?php
    /* Your Twitter App Info  */
    
    // Consumer Key
    define('CONSUMER_KEY', 'XoanmSoZzYK8y3y0dilIKbISn');
    define('CONSUMER_SECRET', 'tzflOLf3vjQ4mFuxqdW3LOKJMJ7eusDiJiZF8fQuoNiS1F8c3i');

    // User Access Token
    define('ACCESS_TOKEN', '3139137656-TWA1t7B8QFrgVAmA5xPfSJ1swaAOgAnNFuT1QO8');
    define('ACCESS_SECRET', 'p2bNtHo17cqxwTo8zUywLvpsLIEIoA82axvKoyndbinp0');
    
    // Cache Settings
    define('CACHE_ENABLED', false);
    define('CACHE_LIFETIME', 3600); // in seconds
    define('HASH_SALT', md5(dirname(__FILE__)));